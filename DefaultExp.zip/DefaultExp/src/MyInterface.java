public interface MyInterface {
		   public static int num = 100;
		   public default void display() {
		      System.out.println("This is default");
		   }
		}