import java.util.concurrent.ExecutorService;  
import java.util.concurrent.Executors;  
import java.util.concurrent.ThreadPoolExecutor;  
import java.util.concurrent.TimeUnit;  
  
public class ExecutorsnewWorkStealingPoo  {  
      
   public static void main(final String[] arguments) throws InterruptedException {  
      ExecutorService excr = Executors.newWorkStealingPool();  
      ThreadPoolExecutor mypool = (ThreadPoolExecutor)  Executors.newCachedThreadPool();;  
      System.out.println("size of mypool: " + mypool.getPoolSize());  
      excr.submit(new Threadimpl());  
      excr.submit(new Threadimpl());  
      System.out.println("Total number threads scheduled): "+ mypool.getTaskCount());  
      excr.shutdown();  
   }}