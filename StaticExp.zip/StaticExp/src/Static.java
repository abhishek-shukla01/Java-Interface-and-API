
public class Static{
		   public void demo() {
		      System.out.println("This is the implementation of the demo method");
		   }
		   public static void main(String args[]) {
		      Static obj = new Static();
		      obj.demo();
		      MyInterface.display();
		   }
		}