public interface MyInterface{
	   public void demo();
	   public static void display() {
	      System.out.println("This is a static method");
	   }
	}